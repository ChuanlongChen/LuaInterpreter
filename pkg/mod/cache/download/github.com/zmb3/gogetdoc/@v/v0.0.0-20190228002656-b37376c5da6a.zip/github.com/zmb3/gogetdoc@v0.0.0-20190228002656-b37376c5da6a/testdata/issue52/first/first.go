package first

import "issue52/first/second"

//V this works
var V second.T
