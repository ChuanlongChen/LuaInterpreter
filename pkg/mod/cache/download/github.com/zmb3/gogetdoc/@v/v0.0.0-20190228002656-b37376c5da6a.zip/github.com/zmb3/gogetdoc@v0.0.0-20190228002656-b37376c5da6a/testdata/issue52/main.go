package main

import (
	"issue52/first"
)

func main() {
	first.V.Foo()
}
